// Function to change the color of an element
function changeColor(elementId, color) {
    var element = document.getElementById(elementId);
    element.style.color = color;
}